const { MessageFlags, Routes } = require('discord.js');

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    if (interaction.isButton() && interaction.customId.startsWith('spam:')) {
      try {
        await handleSpamButton(client, interaction);
      } catch (error) {
        console.error('spam button error:', error);
      }
      return;
    }

    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction, { client });
    } catch (error) {
      if (error?.code === 10062) return;
      console.error(`Command /${interaction.commandName} error:`, error);
      try {
        if (!interaction.isRepliable()) return;
        if (interaction.deferred) {
          await interaction.editReply({ content: 'Bu komut çalıştırılırken bir hata oluştu.' });
        } else {
          await interaction.reply({ content: 'Bu komut çalıştırılırken bir hata oluştu.', flags: MessageFlags.Ephemeral });
        }
      } catch {
      }
    }
  },
};

async function handleSpamButton(client, interaction) {
  const control = interaction.message;
  const controlId = control?.id;
  const pending = controlId ? client.pendingSpam?.get(controlId) : undefined;
  const isSend = interaction.customId === 'spam:send';
  const mesaj = (pending?.mesaj ?? control?.content ?? '').slice(0, 1500);
  const count = pending?.count ?? 50;
  const gecikme = pending?.gecikme ?? 1000;

  if (!pending) {
    console.warn(`Spam verisi bulunamadı: controlId=${controlId}`);
    try {
      await interaction.reply({ content: '❌ Spam verisi bulunamadı. Komutu tekrar çalıştır.', flags: MessageFlags.Ephemeral });
    } catch {
    }
    return;
  }

  if (pending?.userId && interaction.user.id !== pending.userId) {
    try {
      await interaction.reply({ content: 'Bu buton sana ait değil.', flags: MessageFlags.Ephemeral });
    } catch {
    }
    return;
  }

  if (pending?.sending || pending?.done) {
    try {
      await interaction.reply({ content: 'Bu spam zaten gönderildi.', flags: MessageFlags.Ephemeral });
    } catch {
    }
    return;
  }

  if (!isSend) {
    if (controlId) client.pendingSpam?.delete(controlId);
    try {
      await interaction.update({ content: 'İptal edildi.', components: [] });
    } catch {
    }
    await deleteControl(client, interaction, pending, controlId);
    return;
  }

  if (pending) pending.sending = true;

  // Grup modu kontrolü
  const isGrup = pending?.grupMode === true;
  const grupKullanicilar = pending?.grupKullanicilar ?? [];
  const isMentionRandom = pending?.mentionRandomMode === true;

  if (isMentionRandom) {
    // Mention-random modu — sunucudaki random kullanıcıları mention et
    if (!interaction.guild) {
      try {
        await interaction.reply({ content: '❌ Bu komut sunucuda çalışmalıdır.', flags: MessageFlags.Ephemeral });
      } catch {
      }
      return;
    }

    try {
      await interaction.update({ content: `⏳ Random mention spamı gönderiliyor...`, components: [] });
    } catch (error) {
      if (pending) pending.sending = false;
      if (error?.code === 10062) return;
      console.error('spam update error:', error);
      return;
    }

    const kisiSayi = pending?.kisiSayi ?? 3;

    // Members'ı döngüden önce bir kez al
    let allMembers = [];
    try {
      const members = await interaction.guild.members.fetch({ limit: 100 });
      allMembers = Array.from(members.values())
        .filter(m => m.id !== client.user.id);
    } catch (err) {
      console.error('Members fetch hatası:', err?.code ?? err?.message);
      allMembers = [];
    }

    if (allMembers.length === 0) {
      try {
        await interaction.reply({ content: '❌ Sunucuda yeterli üye bulunamadı.', flags: MessageFlags.Ephemeral });
      } catch {
      }
      await deleteControl(client, interaction, pending, controlId);
      if (pending) pending.done = true;
      return;
    }

    for (let i = 0; i < count; i++) {
      if (pending?.stopped) break;
      if (i > 0) await wait(gecikme);

      try {
        // Her döngüde random üyeler seç
        const randomMembers = [];
        const selectCount = Math.min(kisiSayi, allMembers.length);
        
        // Fisher-Yates shuffle ile random seçim
        for (let j = 0; j < selectCount; j++) {
          const randomIndex = Math.floor(Math.random() * allMembers.length);
          randomMembers.push(allMembers[randomIndex]);
          allMembers.splice(randomIndex, 1);
        }
        
        // Yeniden listele (tekrar seçim için)
        if (allMembers.length === 0) {
          const members = await interaction.guild.members.fetch({ limit: 100 });
          allMembers = Array.from(members.values())
            .filter(m => m.id !== client.user.id);
        }

        // Mention mesajını oluştur
        const mentions = randomMembers.map(m => `<@${m.id}>`).join(' ');
        const fullMessage = pending?.mesaj
          ? `${mentions} ${pending.mesaj}`
          : mentions;

        await client.rest.post(Routes.channelMessages(interaction.channelId), {
          body: { content: fullMessage.slice(0, 1500) },
        });
      } catch (error) {
        const code = error?.code ?? error?.status;
        if (code === 429) {
          const retryAfter = (error?.rawError?.retry_after ?? 1) * 1000;
          console.warn(`spam rate limit, ${retryAfter}ms bekleniyor`);
          await wait(retryAfter);
          i--;
          continue;
        }
        console.error(`mention-random mesaj ${i + 1} hatası:`, code, error?.rawError ?? error?.message);
        if (code === 10003 || code === 50001 || code === 50013 || code === 404) break;
      }
    }
  } else if (isGrup && grupKullanicilar.length > 0) {
    // Grup spamı — her kullanıcı için ayrı ayrı DM aç ve mesaj gönder
    try {
      await interaction.update({ content: `⏳ ${grupKullanicilar.length} kişiye gönderiliyor...`, components: [] });
    } catch (error) {
      if (pending) pending.sending = false;
      if (error?.code === 10062) return;
      console.error('spam update error:', error);
      return;
    }

    for (const userId of grupKullanicilar) {
      if (pending?.stopped) break;

      let dmChannelId;
      try {
        const dmChannel = await client.users.createDM(userId);
        dmChannelId = dmChannel.id;
      } catch (err) {
        console.error(`${userId} DM açılamadı:`, err?.code ?? err?.message);
        continue;
      }

      // Her kullanıcıya count kadar mesaj gönder
      for (let i = 0; i < count; i++) {
        if (pending?.stopped) break;
        if (i > 0) await wait(gecikme);

        try {
          await client.rest.post(Routes.channelMessages(dmChannelId), {
            body: { content: mesaj },
          });
        } catch (error) {
          const code = error?.code ?? error?.status;
          if (code === 429) {
            const retryAfter = (error?.rawError?.retry_after ?? 1) * 1000;
            console.warn(`spam rate limit, ${retryAfter}ms bekleniyor`);
            await wait(retryAfter);
            i--;
            continue;
          }
          console.error(`grup spam ${userId} mesaj ${i + 1} hatası:`, code, error?.rawError ?? error?.message);
          if (code === 10003 || code === 50001 || code === 50007 || code === 50013 || code === 50278 || code === 404) break;
        }
      }
    }
  } else {
    // Normal spam (tek kullanıcı veya kanal)
    let targetChannelId = pending?.channelId ?? interaction.channelId;
    const hedefKullaniciId = pending?.hedefKullaniciId ?? null;

    if (hedefKullaniciId) {
      // Kullanıcı parametresiyle seçildi → o kişiye DM aç
      try {
        const dmChannel = await client.users.createDM(hedefKullaniciId);
        targetChannelId = dmChannel.id;
      } catch (err) {
        console.error('Hedef kullanıcıya DM kanalı açılamadı:', err?.code ?? err?.message);
      }
    } else if (!interaction.guildId) {
      // DM'de çalıştırıldı, kullanıcı seçilmedi → karşı tarafı bul
      const recipientId = interaction.channel?.recipientId
        ?? interaction.channel?.recipient?.id;

      if (recipientId && recipientId !== interaction.user.id) {
        targetChannelId = interaction.channelId;
      }
    }

    try {
      await interaction.update({ content: '⏳ Gönderiliyor...', components: [] });
    } catch (error) {
      if (pending) pending.sending = false;
      if (error?.code === 10062) return;
      console.error('spam update error:', error);
      return;
    }

    for (let i = 0; i < count; i++) {
      if (pending?.stopped) break;

      if (i > 0) await wait(gecikme);

      try {
        await client.rest.post(Routes.channelMessages(targetChannelId), {
          body: { content: mesaj },
        });
      } catch (error) {
        const code = error?.code ?? error?.status;
        if (code === 429) {
          const retryAfter = (error?.rawError?.retry_after ?? 1) * 1000;
          console.warn(`spam rate limit, ${retryAfter}ms bekleniyor`);
          await wait(retryAfter);
          i--;
          continue;
        }
        console.error(`spam mesaj ${i + 1} hatası:`, code, error?.rawError ?? error?.message);
        if (code === 10003 || code === 50001 || code === 50007 || code === 50013 || code === 50278 || code === 404) break;
      }
    }
  }

  // Spam bitti, kontrol mesajını sil
  await deleteControl(client, interaction, pending, controlId);
  if (pending) pending.done = true;
  if (controlId) {
    setTimeout(() => client.pendingSpam?.delete(controlId), 60 * 1000)?.unref?.();
  }
}

async function deleteControl(client, interaction, pending, controlId) {
  try {
    await interaction.message?.delete();
    return;
  } catch {
  }
  try {
    await interaction.deleteReply();
    return;
  } catch {
  }
  if (pending?.slashToken && pending?.appId) {
    try {
      await client.rest.delete(
        Routes.webhookMessage(pending.appId, pending.slashToken, controlId),
        { auth: false },
      );
    } catch {
    }
  }
}
