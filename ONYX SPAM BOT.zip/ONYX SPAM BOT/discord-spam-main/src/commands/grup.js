const {
  SlashCommandBuilder,
  ApplicationIntegrationType,
  InteractionContextType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('grup')
    .setDescription('Birden fazla kullanıcıya aynı anda DM spam yapar.')
    .addStringOption((opt) =>
      opt
        .setName('mesaj')
        .setDescription('Gönderilecek mesaj')
        .setRequired(true)
        .setMaxLength(1500),
    )
    .addStringOption((opt) =>
      opt
        .setName('kullanicilar')
        .setDescription('Kullanıcı ID\'leri (virgülle ayır, örnek: 123456789,987654321)')
        .setRequired(true)
        .setMaxLength(1000),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('sayi')
        .setDescription('Her kullanıcıya kaç mesaj gönderilsin? (varsayılan: 10, max: 500)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(500),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('gecikme')
        .setDescription('Mesajlar arası bekleme ms (varsayılan: 2000, min: 1000)')
        .setRequired(false)
        .setMinValue(1000)
        .setMaxValue(10000),
    )
    .setIntegrationTypes([
      ApplicationIntegrationType.GuildInstall,
      ApplicationIntegrationType.UserInstall,
    ])
    .setContexts([
      InteractionContextType.Guild,
      InteractionContextType.BotDM,
      InteractionContextType.PrivateChannel,
    ]),

  async execute(interaction, { client }) {
    const mesaj = interaction.options.getString('mesaj', true).slice(0, 1500);
    const kullanicilarStr = interaction.options.getString('kullanicilar', true);
    const sayi = interaction.options.getInteger('sayi') ?? 10;
    const gecikme = interaction.options.getInteger('gecikme') ?? 2000;

    // ID'leri ayır ve temizle
    const userIds = kullanicilarStr
      .split(',')
      .map(id => id.trim())
      .filter(id => /^\d{17,20}$/.test(id))
      .slice(0, 10); // Max 10 kişi

    if (userIds.length === 0) {
      return interaction.reply({
        content: '❌ Geçerli kullanıcı ID\'si girmedin. Örnek: `123456789,987654321`',
        flags: MessageFlags.Ephemeral,
      });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('spam:send')
        .setLabel('Gönder')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('spam:cancel')
        .setLabel('İptal')
        .setStyle(ButtonStyle.Secondary),
    );

    await interaction.reply({
      content: `👥 **Hedefler:** ${userIds.length} kişi\n📨 **Mesaj:** ${mesaj}\n🔢 **Kişi başı sayı:** ${sayi}\n⏱️ **Gecikme:** ${gecikme}ms`,
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
    const control = await interaction.fetchReply();

    client.pendingSpam?.set(control.id, {
      mesaj,
      count: sayi,
      gecikme,
      userId: interaction.user.id,
      grupKullanicilar: userIds, // Array olarak kaydediyoruz
      channelId: interaction.channelId,
      guildId: interaction.guildId ?? null,
      slashToken: interaction.token,
      appId: interaction.applicationId,
      sending: false,
      done: false,
      grupMode: true, // Bu bir grup spamı
    });

    const timer = setTimeout(() => client.pendingSpam?.delete(control.id), 14 * 60 * 1000);
    if (typeof timer.unref === 'function') timer.unref();
  },
};
