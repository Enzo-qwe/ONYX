const {
  SlashCommandBuilder,
  ApplicationIntegrationType,
  InteractionContextType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tekrar')
    .setDescription('Son spam komutunu tekrar çalıştırır.')
    .setIntegrationTypes([
      ApplicationIntegrationType.GuildInstall,
      ApplicationIntegrationType.UserInstall,
    ])
    .setContexts([
      InteractionContextType.Guild,
      InteractionContextType.BotDM,
      InteractionContextType.PrivateChannel,
    ]),

  async execute(interaction, { client }) {
    client.lastSpam = client.lastSpam ?? new Map();
    const last = client.lastSpam.get(interaction.user.id);

    if (!last) {
      return interaction.reply({
        content: '❌ Daha önce bir spam komutu kullanmadın.',
        flags: MessageFlags.Ephemeral,
      });
    }

    const { mesaj, sayi, gecikme, hedefKullaniciId } = last;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('spam:send')
        .setLabel('Gönder')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('spam:cancel')
        .setLabel('İptal')
        .setStyle(ButtonStyle.Secondary),
    );

    await interaction.reply({
      content: `📨 **Mesaj:** ${mesaj}\n🔢 **Sayı:** ${sayi}\n⏱️ **Gecikme:** ${gecikme}ms`,
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
    const control = await interaction.fetchReply();

    client.pendingSpam?.set(control.id, {
      mesaj,
      count: sayi,
      gecikme,
      userId: interaction.user.id,
      hedefKullaniciId: hedefKullaniciId ?? null,
      channelId: interaction.channelId,
      guildId: interaction.guildId ?? null,
      slashToken: interaction.token,
      appId: interaction.applicationId,
      sending: false,
      done: false,
    });
    const timer = setTimeout(() => client.pendingSpam?.delete(control.id), 14 * 60 * 1000);
    if (typeof timer.unref === 'function') timer.unref();
  },
};
