const {
  SlashCommandBuilder,
  ApplicationIntegrationType,
  InteractionContextType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mention')
    .setDescription('Bir kullanıcıyı etiketleyerek spam yapar.')
    .addUserOption((opt) =>
      opt
        .setName('kullanici')
        .setDescription('Etiketlenecek kullanıcı')
        .setRequired(true),
    )
    .addStringOption((opt) =>
      opt
        .setName('mesaj')
        .setDescription('Etiketle birlikte gönderilecek mesaj (boş bırakılabilir)')
        .setRequired(false)
        .setMaxLength(1400),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('sayi')
        .setDescription('Kaç kez gönderilsin? (varsayılan: 50, max: 500)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(500),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('gecikme')
        .setDescription('Mesajlar arası bekleme süresi ms cinsinden (varsayılan: 1000, min: 500)')
        .setRequired(false)
        .setMinValue(500)
        .setMaxValue(10000),
    )
    .setIntegrationTypes([
      ApplicationIntegrationType.GuildInstall,
      ApplicationIntegrationType.UserInstall,
    ])
    .setContexts([
      InteractionContextType.Guild,
      InteractionContextType.BotDM,
      InteractionContextType.PrivateChannel,
    ]),

  async execute(interaction, { client }) {
    const hedefKullanici = interaction.options.getUser('kullanici', true);
    const ekMesaj = interaction.options.getString('mesaj') ?? '';
    const sayi = interaction.options.getInteger('sayi') ?? 50;
    const gecikme = interaction.options.getInteger('gecikme') ?? 1000;

    // Mention + ek mesaj birleştir
    const mesaj = ekMesaj
      ? `<@${hedefKullanici.id}> ${ekMesaj}`.slice(0, 1500)
      : `<@${hedefKullanici.id}>`;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('spam:send')
        .setLabel('Gönder')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('spam:cancel')
        .setLabel('İptal')
        .setStyle(ButtonStyle.Secondary),
    );

    await interaction.reply({
      content: `👤 **Hedef:** <@${hedefKullanici.id}>\n🔢 **Sayı:** ${sayi}\n⏱️ **Gecikme:** ${gecikme}ms`,
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
    const control = await interaction.fetchReply();

    // Son spam ayarlarını kaydet (tekrar komutu için)
    client.lastSpam = client.lastSpam ?? new Map();
    client.lastSpam.set(interaction.user.id, { mesaj, sayi, gecikme, hedefKullaniciId: null, isMention: true });

    client.pendingSpam?.set(control.id, {
      mesaj,
      count: sayi,
      gecikme,
      userId: interaction.user.id,
      hedefKullaniciId: null, // mention spamda DM değil mevcut kanala yaz
      channelId: interaction.channelId,
      guildId: interaction.guildId ?? null,
      slashToken: interaction.token,
      appId: interaction.applicationId,
      sending: false,
      done: false,
    });
    const timer = setTimeout(() => client.pendingSpam?.delete(control.id), 14 * 60 * 1000);
    if (typeof timer.unref === 'function') timer.unref();
  },
};
