const {
  SlashCommandBuilder,
  ApplicationIntegrationType,
  InteractionContextType,
  MessageFlags,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('durdur')
    .setDescription('Devam eden spam işlemini durdurur.')
    .setIntegrationTypes([
      ApplicationIntegrationType.GuildInstall,
      ApplicationIntegrationType.UserInstall,
    ])
    .setContexts([
      InteractionContextType.Guild,
      InteractionContextType.BotDM,
      InteractionContextType.PrivateChannel,
    ]),

  async execute(interaction, { client }) {
    let found = false;

    for (const [id, data] of client.pendingSpam.entries()) {
      if (data.userId !== interaction.user.id) continue;
      if (data.done) continue;

      // stopped flag'ini set et — aktif döngü bunu kontrol edip duracak
      data.stopped = true;
      data.done = true;
      // Eğer henüz gönderilmeye başlanmadıysa map'ten de sil
      if (!data.sending) {
        client.pendingSpam.delete(id);
      }
      found = true;
    }

    if (found) {
      await interaction.reply({
        content: '✅ Spam durduruldu.',
        flags: MessageFlags.Ephemeral,
      });
    } else {
      await interaction.reply({
        content: '❌ Durdurulacak aktif bir spam bulunamadı.',
        flags: MessageFlags.Ephemeral,
      });
    }
  },
};
