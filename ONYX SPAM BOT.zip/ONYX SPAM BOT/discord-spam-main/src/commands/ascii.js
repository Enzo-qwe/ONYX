const {
  SlashCommandBuilder,
  ApplicationIntegrationType,
  InteractionContextType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require('discord.js');

// ASCII art koleksiyonu
const ASCII_ARTS = {
  'skulls': `
☠️ ☠️ ☠️ ☠️ ☠️ ☠️ ☠️ ☠️
☠️ ☠️ ☠️ ☠️ ☠️ ☠️ ☠️ ☠️
☠️ ☠️ ☠️ ☠️ ☠️ ☠️ ☠️ ☠️
  `,
  'heart': `
❤️ ❤️ ❤️ ❤️ ❤️ ❤️ ❤️ ❤️
❤️ ❤️ ❤️ ❤️ ❤️ ❤️ ❤️ ❤️
❤️ ❤️ ❤️ ❤️ ❤️ ❤️ ❤️ ❤️
  `,
  'fire': `
🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥
🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥
🔥 🔥 🔥 🔥 🔥 🔥 🔥 🔥
  `,
  'clown': `
🤡 🤡 🤡 🤡 🤡 🤡 🤡 🤡
🤡 🤡 🤡 🤡 🤡 🤡 🤡 🤡
🤡 🤡 🤡 🤡 🤡 🤡 🤡 🤡
  `,
  'money': `
💰 💰 💰 💰 💰 💰 💰 💰
💰 💰 💰 💰 💰 💰 💰 💰
💰 💰 💰 💰 💰 💰 💰 💰
  `,
  'gun': `
🔫 🔫 🔫 🔫 🔫 🔫 🔫 🔫
🔫 🔫 🔫 🔫 🔫 🔫 🔫 🔫
🔫 🔫 🔫 🔫 🔫 🔫 🔫 🔫
  `,
  'middle': `
🖕 🖕 🖕 🖕 🖕 🖕 🖕 🖕
🖕 🖕 🖕 🖕 🖕 🖕 🖕 🖕
🖕 🖕 🖕 🖕 🖕 🖕 🖕 🖕
  `,
  'pyramid': `
    🔺
   🔺 🔺
  🔺 🔺 🔺
 🔺 🔺 🔺 🔺
  `,
  'rainbow': `
🌈 🌈 🌈 🌈 🌈 🌈 🌈 🌈
🌈 🌈 🌈 🌈 🌈 🌈 🌈 🌈
🌈 🌈 🌈 🌈 🌈 🌈 🌈 🌈
  `,
  'stars': `
⭐ ⭐ ⭐ ⭐ ⭐ ⭐ ⭐ ⭐
⭐ ⭐ ⭐ ⭐ ⭐ ⭐ ⭐ ⭐
⭐ ⭐ ⭐ ⭐ ⭐ ⭐ ⭐ ⭐
  `,
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ascii')
    .setDescription('ASCII sanatı spam yapar.')
    .addStringOption((opt) => {
      opt
        .setName('stil')
        .setDescription('ASCII stil seç')
        .setRequired(true);
      
      // Dinamik olarak seçenekleri ekle
      for (const style of Object.keys(ASCII_ARTS)) {
        opt.addChoices({ name: style, value: style });
      }
      
      return opt;
    })
    .addIntegerOption((opt) =>
      opt
        .setName('sayi')
        .setDescription('Kaç kez gönderilsin? (varsayılan: 50, max: 500)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(500),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('gecikme')
        .setDescription('Mesajlar arası bekleme ms (varsayılan: 1000, min: 500)')
        .setRequired(false)
        .setMinValue(500)
        .setMaxValue(10000),
    )
    .setIntegrationTypes([
      ApplicationIntegrationType.GuildInstall,
      ApplicationIntegrationType.UserInstall,
    ])
    .setContexts([
      InteractionContextType.Guild,
      InteractionContextType.BotDM,
      InteractionContextType.PrivateChannel,
    ]),

  async execute(interaction, { client }) {
    const stil = interaction.options.getString('stil', true);
    const sayi = interaction.options.getInteger('sayi') ?? 50;
    const gecikme = interaction.options.getInteger('gecikme') ?? 1000;

    const mesaj = ASCII_ARTS[stil] || ASCII_ARTS['skulls'];

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('spam:send')
        .setLabel('Gönder')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('spam:cancel')
        .setLabel('İptal')
        .setStyle(ButtonStyle.Secondary),
    );

    await interaction.reply({
      content: `🎨 **ASCII Sanatı Spam**\n📝 **Stil:** ${stil}\n🔢 **Sayı:** ${sayi}\n⏱️ **Gecikme:** ${gecikme}ms\n\n${mesaj}`,
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
    const control = await interaction.fetchReply();

    // Son spam ayarlarını kaydet (tekrar komutu için)
    client.lastSpam = client.lastSpam ?? new Map();
    client.lastSpam.set(interaction.user.id, { mesaj, sayi, gecikme, hedefKullaniciId: null });

    client.pendingSpam?.set(control.id, {
      mesaj,
      count: sayi,
      gecikme,
      userId: interaction.user.id,
      hedefKullaniciId: null,
      channelId: interaction.channelId,
      guildId: interaction.guildId ?? null,
      slashToken: interaction.token,
      appId: interaction.applicationId,
      sending: false,
      done: false,
    });

    const timer = setTimeout(() => client.pendingSpam?.delete(control.id), 14 * 60 * 1000);
    if (typeof timer.unref === 'function') timer.unref();
  },
};
