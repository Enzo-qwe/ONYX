const {
  SlashCommandBuilder,
  ApplicationIntegrationType,
  InteractionContextType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mention-random')
    .setDescription('Sunucudaki random kullanıcıları mention ederek spam yapar.')
    .addIntegerOption((opt) =>
      opt
        .setName('sayi')
        .setDescription('Kaç mesaj gönderilsin? (varsayılan: 50, max: 500)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(500),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('kisisayi')
        .setDescription('Her mesajda kaç kişi mention edilsin? (varsayılan: 3, max: 10)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(10),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('gecikme')
        .setDescription('Mesajlar arası bekleme ms (varsayılan: 1000, min: 500)')
        .setRequired(false)
        .setMinValue(500)
        .setMaxValue(10000),
    )
    .addStringOption((opt) =>
      opt
        .setName('mesaj')
        .setDescription('Mention\'ların yanında eklenecek mesaj (opsiyonel)')
        .setRequired(false)
        .setMaxLength(1000),
    )
    .setIntegrationTypes([
      ApplicationIntegrationType.GuildInstall,
    ])
    .setContexts([
      InteractionContextType.Guild,
    ]),

  async execute(interaction, { client }) {
    // Sunucu kontrolü
    if (!interaction.guild) {
      return interaction.reply({
        content: '❌ Bu komut sadece sunucu kanallarında kullanılabilir.',
        flags: MessageFlags.Ephemeral,
      });
    }

    const sayi = interaction.options.getInteger('sayi') ?? 50;
    const kisiSayi = interaction.options.getInteger('kisisayi') ?? 3;
    const gecikme = interaction.options.getInteger('gecikme') ?? 1000;
    const ekMesaj = interaction.options.getString('mesaj') ?? '';

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('spam:send')
        .setLabel('Gönder')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('spam:cancel')
        .setLabel('İptal')
        .setStyle(ButtonStyle.Secondary),
    );

    await interaction.reply({
      content: `🎲 **Random Mention Spam**\n🔢 **Mesaj sayısı:** ${sayi}\n👥 **Kişi sayısı:** ${kisiSayi}\n⏱️ **Gecikme:** ${gecikme}ms`,
      components: [row],
      flags: MessageFlags.Ephemeral,
    });
    const control = await interaction.fetchReply();

    // Son spam ayarlarını kaydet (tekrar komutu için)
    client.lastSpam = client.lastSpam ?? new Map();
    client.lastSpam.set(interaction.user.id, { mesaj: ekMesaj, sayi, gecikme, hedefKullaniciId: null, isMentionRandom: true });

    client.pendingSpam?.set(control.id, {
      mesaj: ekMesaj,
      count: sayi,
      gecikme,
      userId: interaction.user.id,
      channelId: interaction.channelId,
      guildId: interaction.guildId,
      slashToken: interaction.token,
      appId: interaction.applicationId,
      sending: false,
      done: false,
      mentionRandomMode: true,
      kisiSayi,
    });

    const timer = setTimeout(() => client.pendingSpam?.delete(control.id), 14 * 60 * 1000);
    if (typeof timer.unref === 'function') timer.unref();
  },
};
